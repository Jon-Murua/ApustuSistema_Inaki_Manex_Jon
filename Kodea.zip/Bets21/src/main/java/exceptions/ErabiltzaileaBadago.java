package exceptions;

public class ErabiltzaileaBadago extends Exception {

}
