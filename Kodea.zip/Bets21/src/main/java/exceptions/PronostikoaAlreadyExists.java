package exceptions;

public class PronostikoaAlreadyExists extends Exception {

}
