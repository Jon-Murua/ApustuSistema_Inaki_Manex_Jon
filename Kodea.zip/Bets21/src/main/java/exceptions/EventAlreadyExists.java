package exceptions;

public class EventAlreadyExists extends Exception {

}
