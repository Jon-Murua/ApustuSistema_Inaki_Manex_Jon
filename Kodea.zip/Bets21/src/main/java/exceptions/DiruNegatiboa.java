package exceptions;

public class DiruNegatiboa extends Exception {

}
