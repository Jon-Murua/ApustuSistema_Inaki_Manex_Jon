package exceptions;

public class DiruFalta extends Exception {

}
