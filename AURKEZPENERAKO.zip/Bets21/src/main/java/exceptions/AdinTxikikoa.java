package exceptions;

public class AdinTxikikoa extends Exception {

}
