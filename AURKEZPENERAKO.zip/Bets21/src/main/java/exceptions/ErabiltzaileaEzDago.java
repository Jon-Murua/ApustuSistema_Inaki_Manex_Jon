package exceptions;

public class ErabiltzaileaEzDago extends Exception {

}
