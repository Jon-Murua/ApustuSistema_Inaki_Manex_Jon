package exceptions;

public class PasahitzaOkerra extends Exception {

	
	
}
